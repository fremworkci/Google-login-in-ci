first download vendor folder by composer
composer require google/apiclient:"^2.0"

Google_login.php is controller
Google_login_model.php is a model
google_login.php is view